import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor() { }

  users:any[]=[
    {email:"abc@gmail.com",pass:"345"},
    {email:"cde@gmail.com",pass:"111"},
  ]
  users_object:any={};
  addSuccessMessage:number=0

 addUser(e:any,p:any){
 this.users_object={email:e,pass:p};
 this.users.push(this.users_object);
 }

 getData(){
  return this.users;
 }
}
