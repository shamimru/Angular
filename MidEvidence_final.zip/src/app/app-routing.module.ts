import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LogInComponent } from './log-in/log-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AppComponent } from './app.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SuccessComponent } from './success/success.component';
import { FailComponent } from './fail/fail.component';
import { AllDataComponent } from './all-data/all-data.component';

const routes: Routes = [
  {path:"",redirectTo :"signin", pathMatch:"full"},
  {path:"signup",component:SignUpComponent},
  {path:"signin",component:LogInComponent},
  {path:"dropdown",component:DropdownComponent},
  {path:"success",component:SuccessComponent},
  {path:"fail",component:FailComponent},
  {path:"allData",component:AllDataComponent},

  {path:"**",component:PageNotFoundComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
