import { Component, OnInit } from '@angular/core';
import { UsersService } from '../service/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  email2:string=""
  password2:string=""

  users:any={}
  constructor(private myservice:UsersService,private router:Router) { 
    this.myArray=this.myservice.getData().slice();

  }

  ngOnInit(): void {
  }

  allUsers:any[]=[
    {userName:"shamim", password:123}
  ]

  myArray:any[]=[];

  // getData(){
    
  // }

  searchData:any={}
  findData(x:any,y:any){
    this.myArray=this.myservice.getData().slice();
    this.searchData=this.myArray.find(r=> (r.email == x) && (r.pass == y));

    if(this.searchData != null){
      this.router.navigateByUrl("success")
    }else{
      this.router.navigateByUrl("fsf")
    }
  }

  // setData(a:any,b:any){
    
  // }

}