import { Component, OnInit } from '@angular/core';
import { UsersService } from '../service/users.service';

@Component({
  selector: 'app-all-data',
  templateUrl: './all-data.component.html',
  styleUrls: ['./all-data.component.css']
})
export class AllDataComponent implements OnInit {

  constructor(private myServices:UsersService) { 
    this.myArray=this.myServices.getData().slice();
  }

  ngOnInit(): void {
   
  }

  myArray:any[]=[];

  object_1:any={}


  showData(){
    this.myArray=this.myServices.getData().slice();
  }
}
