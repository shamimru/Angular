import { Component, OnInit } from '@angular/core';
import { UsersService } from '../service/users.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  constructor(private myServices:UsersService) { 
    this.myArray=this.myServices.getData().slice();
  }

  ngOnInit(): void {
   
  }

  myArray:any[]=[];

  object_1:any={}

  email:any;
  pass:any
  setData(e:any, pass:any){
    this.object_1={id:e,name:pass};
    this.myServices.users.push(this.object_1);
    }

  showData(){
    this.myArray=this.myServices.getData().slice();
  }
}
