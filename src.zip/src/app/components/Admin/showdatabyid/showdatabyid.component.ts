import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-showdatabyid',
  templateUrl: './showdatabyid.component.html',
  styleUrls: ['./showdatabyid.component.css']
})
export class ShowdatabyidComponent implements OnInit {

  constructor(private _myservice:UserService) { }

  ngOnInit(): void {
  }


  id:any;
  allData:any;
  submitSearchById(){
    this._myservice.searchDataById(this.id).subscribe((data:any)=>{
      this.allData=data;
    })
  }
}
